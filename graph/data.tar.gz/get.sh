#!/bin/bash
wget https://desertbus.org/static/donations.json -O year9.json
